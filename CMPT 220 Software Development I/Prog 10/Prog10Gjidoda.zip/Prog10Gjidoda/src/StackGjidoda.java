/**
 * 
 * @author Joey0027
 * 
 *         This is class definition for StackGjidoda
 *
 */
public class StackGjidoda
{
	/**
	 * Instance variable for MAXSIZE
	 */
	private static final int MAXSIZE = 100;

	/**
	 * Instance variable for myList
	 */
	private CardGjidoda[] myList;

	/**
	 * Instance variable for myTop
	 */
	private int myTop;

	/**
	 * constructor
	 */
	public StackGjidoda()
	{
		myList = new CardGjidoda[MAXSIZE];
		for (int i = 0; i < MAXSIZE; i++)
		{
			myList[i] = null;
		} // for
		myTop = -1;
	}// Stack

	/**
	 * method that adds new card
	 * 
	 * @param newPush incoming card
	 * @return t or f if added
	 */
	public boolean push(CardGjidoda newPush)
	{
		boolean pushed = false;

		if (!isFull())
		{
			myTop++;
			myList[myTop] = newPush;
			pushed = true;
		} // if

		return pushed;
	}// push

	/**
	 * method that removes card
	 * 
	 * @return card integer
	 */
	public CardGjidoda pop()
	{
		CardGjidoda ans = null;

		if (!isEmpty())
		{
			ans = myList[myTop];
			myTop--;
		} // if
		return ans;
	}// pop

	/**
	 * method that checks if list is full
	 * 
	 * @return t or f if full
	 */
	public boolean isFull()
	{
		boolean full = false;

		if (myTop == MAXSIZE - 1)
		{
			full = true;
		} // if

		return full;
	}// isFull

	/**
	 * method that checks if list is empty
	 * 
	 * @return t or f if empty
	 */
	public boolean isEmpty()
	{
		boolean empty = false;

		if (myTop < 0)
		{
			empty = true;
		} // if
		return empty;
		// return (myTop == -1);
	}// isEmpty
}
