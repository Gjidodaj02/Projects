/**
 * 
 * @author Joey0027 <br>
 *
 *         This is class definition for CardGjidoda
 *
 */
public class CardGjidoda
{
	/**
	 * Instance variable for card value
	 */
	private int myVal;

	/**
	 * Instance variable for card suit
	 */
	private String mySuit;

	/**
	 * null constructor
	 */
	public CardGjidoda()
	{
		myVal = 0;
		mySuit = null;
	}// CardGjidoda

	/**
	 * default constructor
	 * 
	 * @param newVal  incoming value
	 * @param newSuit incoming suit
	 */
	public CardGjidoda(int newVal, String newSuit)
	{
		myVal = newVal;
		mySuit = newSuit;
	}// CardGjidoda

	/**
	 * method that sets new card suit
	 * 
	 * @param newSuit new incoming card suit
	 */
	public void setSuit(String newSuit)
	{
		mySuit = newSuit;
	}// setSuit

	/**
	 * method that sets new card value
	 * 
	 * @param newCardVal new incoming card value
	 */
	public void setCardVal(int newCardVal)
	{
		myVal = newCardVal;
	}// setCardVal

	/**
	 * method that returns card suit
	 * 
	 * @return card suit
	 */
	public String getSuit()
	{
		return mySuit;
	}// getSuit

	/**
	 * method that returns card value
	 * 
	 * @return card value
	 */
	public int getCardVal()
	{
		return myVal;
	}// getCardVal

}// CardGjidoda
