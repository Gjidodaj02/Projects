import java.io.File;
import java.io.FileNotFoundException;
import java.util.InputMismatchException;
import java.util.NoSuchElementException;
import java.util.Scanner;

/**
 * 
 * @author Joey0027 <br>
 * 
 *         Prog 10 <br>
 *         Due Date and Time: 5/17/21 before 9:00 AM <br>
 * 
 *         Purpose: A program that gets file input of cards, deals them out, and
 *         plays war. <br>
 * 
 *         Input: input file <br>
 * 
 *         Output: First greets user and explains the program <br>
 *         Then asks for the file location <br>
 *         Then shows the summary of the game <br>
 *         How many cards it started with <br>
 *         How many plays <br>
 *         If there was a clear winner <br>
 *         Cards left for players <br>
 *         Who the winner was <br>
 * 
 *         Certification of Authenticity:<br>
 * 
 *         I certify that this lab is entirely my own work.<br>
 *
 */
public class BattleDemoGjidoda
{

	/**
	 * universal scanner for ShoppingDemoGjidoda
	 */
	static Scanner keyboard = new Scanner(System.in);

	/**
	 * Global variable for player 1 id
	 */
	static final int player1Id = 1;

	/**
	 * Global variable for player 2 id
	 */
	static final int player2Id = 2;

	/**
	 * Global variable for maxPlayCount
	 */
	static final int maxPlayCount = 1000;

	/**
	 * main method
	 * 
	 * @param args array of strings that is passed through main
	 */
	public static void main(String[] args)
	{
		int playCount = 0, winner = 0;
		boolean isWinner = false;
		StackGjidoda player1PlayStack = new StackGjidoda(), player2PlayStack = new StackGjidoda();
		StackGjidoda player1DiscardStack = new StackGjidoda(), player2DiscardStack = new StackGjidoda();
		CardGjidoda player1Card = null, player2Card = null;

		// greet
		System.out.println("This is a program that plays war!");

		if (deal(player1PlayStack, player2PlayStack))
		{
			do
			{
				if (player1PlayStack.isEmpty() && player1DiscardStack.isEmpty())
				{
					isWinner = true;
				} // if

				else if (player2PlayStack.isEmpty() && player2DiscardStack.isEmpty())
				{
					isWinner = true;
				} // else if

				else
				{
					player1Card = play(player1PlayStack, player1DiscardStack);
					player2Card = play(player2PlayStack, player2DiscardStack);
					// winner is either 1 or 2
					winner = compare(player1Card, player2Card);

					if (winner == player1Id)
					{
						winPlay(player1Card, player2Card, player1DiscardStack);
					} // if

					else if (winner == player2Id)
					{
						winPlay(player2Card, player1Card, player2DiscardStack);
					} // else if

					else
					{
						// Players draw, so each player discard card in their own stack
						winPlay(null, player1Card, player1DiscardStack);
						winPlay(null, player2Card, player2DiscardStack);
					} // else

					playCount++;
				} // else

			} while (playCount < maxPlayCount && !isWinner);

			printResults(playCount, player1PlayStack, player2PlayStack, player1DiscardStack, player2DiscardStack);
		} // while
	}// main

	/**
	 * method that gets the players card
	 * 
	 * @param playStack    incoming play stack
	 * @param discardStack incoming discard stack
	 * @return players card
	 */
	public static CardGjidoda play(StackGjidoda playStack, StackGjidoda discardStack)
	{
		CardGjidoda playersCard = null;

		if (playStack.isEmpty() && !discardStack.isEmpty())
		{
			copy(playStack, discardStack);
		} // if

		if (!playStack.isEmpty())
		{
			playersCard = playStack.pop();
		} // if

		return playersCard;
	}// play

	/**
	 * method that determines winner
	 * 
	 * @param cardPlayer1 incoming player 1 card
	 * @param cardPlayer2 incoming player 2 card
	 * @return winner
	 */
	public static int compare(CardGjidoda cardPlayer1, CardGjidoda cardPlayer2)
	{
		int winner = 0;

		if (cardPlayer1.getCardVal() > cardPlayer2.getCardVal())
		{
			winner = player1Id;
		} // if

		else if (cardPlayer2.getCardVal() > cardPlayer1.getCardVal())
		{
			winner = player2Id;
		} // else if

		else if (cardPlayer1.getCardVal() == cardPlayer2.getCardVal())
		{
			if (cardPlayer1.getSuit().compareToIgnoreCase(cardPlayer2.getSuit()) > 0)
			{
				winner = player1Id;
			} // if

			else if (cardPlayer2.getSuit().compareToIgnoreCase(cardPlayer1.getSuit()) > 0)
			{
				winner = player2Id;
			} // else if
		} // else if

		return winner;
	}// compare

	/**
	 * method that adds cards to winners discard stack
	 * 
	 * @param winnersCard        incoming winners card
	 * @param losersCard         incoming losers card
	 * @param winnerDiscardStack incoming winners discard stack
	 */
	public static void winPlay(CardGjidoda winnersCard, CardGjidoda losersCard, StackGjidoda winnerDiscardStack)
	{
		// Add winners card first
		if (winnersCard != null)
		{
			winnerDiscardStack.push(winnersCard);

		} // if

		if (losersCard != null)
		{
			winnerDiscardStack.push(losersCard);
		} // if

	}// winPlay

	/**
	 * method that copies cards from discard stack to play stack
	 * 
	 * @param playersPlayStack    incoming play stack
	 * @param playersDiscardStack incoming discard stack
	 */
	public static void copy(StackGjidoda playersPlayStack, StackGjidoda playersDiscardStack)
	{
		StackGjidoda temp = new StackGjidoda();
		CardGjidoda val = null;

		while (!playersDiscardStack.isEmpty())
		{
			val = playersDiscardStack.pop();
			temp.push(val);
		} // while

		while (!temp.isEmpty())
		{
			val = temp.pop();
			playersPlayStack.push(val);
		} // while
	}// copy

	/**
	 * method that counts amount of cards in stack
	 * 
	 * @param theStack incoming stack
	 * @return amount of cards in stack
	 */
	public static int countCards(StackGjidoda theStack)
	{
		int ans = 0;
		StackGjidoda temp = new StackGjidoda();
		CardGjidoda theValue = null;

		while (!theStack.isEmpty())
		{
			theValue = theStack.pop();
			temp.push(theValue);
			ans++;
		} // while

		while (!temp.isEmpty())
		{
			theValue = temp.pop();
			theStack.push(theValue);
		} // while

		return ans;
	}// countCards

	/**
	 * method that prints final results
	 * 
	 * @param count          incoming play count
	 * @param player1Stack   incoming player 1 stack
	 * @param player2Stack   incoming player 2 stack
	 * @param player1Discard incoming player 1 discard stack
	 * @param player2Discard incoming player 1 discard stack
	 */
	public static void printResults(int count, StackGjidoda player1Stack, StackGjidoda player2Stack,
			StackGjidoda player1Discard, StackGjidoda player2Discard)
	{
		int player1Total = 0, player2Total, winnerOfGame;

		player1Total = countCards(player1Stack) + countCards(player1Discard);
		player2Total = countCards(player2Stack) + countCards(player2Discard);

		System.out.println("\nBattle Card Game Summary");
		System.out.println("========================");
		System.out.println("The game started with 6 cards.");
		System.out.println("There were " + count + " plays in the game.");

		if (count == maxPlayCount)
		{
			System.out.println("The game took too long.");
		} // if

		if (player1Total > player2Total)
		{
			winnerOfGame = player1Id;
		} // if
		else if (player1Total < player2Total)
		{
			winnerOfGame = player2Id;
		} // else if
		else
		{
			winnerOfGame = 0;
		} // else

		if (winnerOfGame == 0)
		{
			System.out.println("Player 1 ended up with " + (player1Total) + " cards.");
			System.out.println("Player 2 ended up with " + (player2Total) + " cards.");
			System.out.println("The winner was no one.");
		} // if
		else
		{
			System.out.println("The game ended up with a clear winner.");
			System.out.println("Player 1 ended up with " + (player1Total) + " cards.");
			System.out.println("Player 2 ended up with " + (player2Total) + " cards.");
			System.out.println("The winner was player " + winnerOfGame);
		} // else

	}// printResult

	/**
	 * method that loads input file and adds all items
	 * 
	 * @param player1Stack incoming player 1 play stack
	 * @param player2Stack incoming player 2 play stack
	 * @return t or f if processed
	 */
	public static boolean deal(StackGjidoda player1Stack, StackGjidoda player2Stack)
	{
		boolean sucsessful = true;
		File inputFile;
		String fileName = null, inputSuit = null;
		int inputVal = 0;
		CardGjidoda item = null;

		int cardCount = 0;

		// ask the user for the path and name to the file
		System.out.print("First enter the filename with your items: ");
		fileName = keyboard.next();
		// fileName = keyboard.next();

		// the catch for the file
		inputFile = new File(fileName);

		// try to open and use the file, if possible
		try
		{

			Scanner input = new Scanner(inputFile);

			// An exception is thrown if you try to read past the end-of-file.
			while (input.hasNext())
			{
				inputVal = input.nextInt();
				inputSuit = input.next();
				item = new CardGjidoda(inputVal, inputSuit);

				if (cardCount % 2 == 0)
				{
					player1Stack.push(item);
				} // if

				else
				{
					player2Stack.push(item);
				} // else

				cardCount++;
			} // while
			input.close();
		} // try

		catch (FileNotFoundException ex)
		{
			System.out.print("\nFailed to find the file: " + inputFile.getAbsolutePath());
			sucsessful = false;
		} // catch

		catch (InputMismatchException ex)
		{
			System.out.println("\nType of input was not expected for the line being read.");
			System.out.println(ex.getMessage());
			sucsessful = false;
		} // catch

		catch (NumberFormatException ex)
		{
			System.out.println("\nFailed to convert String text into an integer or double value.");
			System.out.println(ex.getMessage());
			sucsessful = false;
		} // catch

		catch (NoSuchElementException ex)
		{
			System.out.println("\nYou might be missing some data. Check for any missing data in your file.");
			sucsessful = false;
		} // catch

		catch (Exception ex)
		{
			// Like an "else" catch(Exception should come last as the catch all.
			System.out.println("\nSomething went wrong, check input file before trying again");
			ex.printStackTrace();
			sucsessful = false;
		} // catch
		return sucsessful;
	}// loadInputFile

}// BattleDemoGjidoda
