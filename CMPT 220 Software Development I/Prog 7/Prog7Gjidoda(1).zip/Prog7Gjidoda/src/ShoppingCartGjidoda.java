import java.io.File;
import java.io.FileNotFoundException;
import java.util.InputMismatchException;
import java.util.NoSuchElementException;
import java.util.Scanner;

/**
 * 
 * @author Joey0027
 *
 *         This is a class definition for StepsGjidoda
 */
public class ShoppingCartGjidoda {

	/**
	 * Instance variable for setting array for items
	 */
	private ItemGjidoda[] myItems;

	/**
	 * Instance variable for size of array
	 */
	private int mySize;

	/**
	 * null constructor
	 */
	public ShoppingCartGjidoda() {
		int i = 0;
		myItems = new ItemGjidoda[10];

		for (i = 0; i >= myItems.length; i++) {
			myItems[i].setName("NONE");
			myItems[i].setQuant(-1111);
			myItems[i].setPrice(999.99);
		} // for

		mySize = 0;
	}// ShoppingCartGjidoda

	/**
	 * method that returns the array size
	 * 
	 * @return size of the array
	 */
	public int getSize() {
		return mySize;
	}// getSize

	/**
	 * method that adds item to cart
	 * 
	 * @param item new incoming item
	 * @return boolean t or f, for if item was added
	 */
	public boolean addToCart(ItemGjidoda item) {
		boolean ans = false;

		if (mySize < myItems.length) {
			myItems[mySize] = item;
			mySize++;
			ans = true;
		} // if
		else {
			ans = false;
		}

		return ans;
	}// addToCart

	/**
	 * method that finds most expensive and returns it
	 * 
	 * @return most expensive item
	 */
	public ItemGjidoda findMostExpensive() {
		double mostExpensive = 0;
		ItemGjidoda mostExpensiveItem = myItems[0];
		int i = 0;

		for (i = 0; i < mySize; i++) {
			if (myItems[i].getPrice() >= mostExpensive) {
				mostExpensiveItem = myItems[i];
			} // if
		} // for

		return mostExpensiveItem;
	}// findMostExpensive

	/**
	 * method that finds least expensive and returns it
	 * 
	 * @return least expensive item
	 */
	public ItemGjidoda findLeastExpensive() {
		double leastExpensive = findMostExpensive().getPrice();
		ItemGjidoda leastExpensiveItem = myItems[0];
		int i = 0;

		for (i = 0; i < mySize; i++) {
			if (myItems[i].getPrice() <= leastExpensive) {
				leastExpensiveItem = myItems[i];
			} // if
		} // for

		return leastExpensiveItem;

	}// findLeastExpensive

	/**
	 * method that calculates the total cost
	 * 
	 * @return total cost
	 */
	public double calcTotal() {
		double total = 0.0;
		int i = 0;

		for (i = 0; i < mySize; i++) {
			total += myItems[i].getQuant() * myItems[i].getPrice();
		} // for

		return total;
	}// caltTotal

	/**
	 * method that finds the total number of items
	 * 
	 * @return number of items
	 */
	public int findNumItems() {
		int numItems = 0;
		int i = 0;

		for (i = 0; i < mySize; i++) {
			numItems += myItems[i].getQuant();
		} // for

		return numItems;
	}// findNumTimes

	/**
	 * method that removes most expensive item
	 */
	public void removeMostExpensive() {
		double maxNum = findMostExpensive().getPrice();
		int i = 0, j = 0;
		ItemGjidoda[] myList = new ItemGjidoda[10];

		for (i = 0, j = 0; i < mySize; i++) {
			if (i != maxNum) {
				myList[j++] = myItems[i];
			} // if
		} // for

		myItems = myList;
		mySize--;
	}// removeMostExpensive

	/**
	 * method that loads input file and adds all items
	 * 
	 * @param nameOfFile the input file location
	 * @return boolean t or f, if items were added or not, as well as wrong input
	 */
	public boolean loadInputFile(File nameOfFile) {
		int i = 0, listValue = 0, inputQuant = 0;
		double inputPrice = 0.0;
		String inputName = null;
		ItemGjidoda newInputItem = new ItemGjidoda(inputName, inputQuant, inputPrice);
		boolean loadSuccessful = true;

		// try to open and use the file, if possible
		try {

			Scanner input = new Scanner(nameOfFile);
			listValue = input.nextInt();

			// An exception is thrown if you try to read past the end-of-file.
			do {
				inputName = input.next();
				inputQuant = input.nextInt();
				inputPrice = input.nextDouble();
				newInputItem = new ItemGjidoda(inputName, inputQuant, inputPrice);

				// add to cart, as well as prompt that it was added
				if (addToCart(newInputItem) == true) {
					if (i == 0) {
						System.out.println("\n" + (i + 1) + " Item added!");
					} // if
					if (i > 0) {
						System.out.println("\n" + (i + 1) + " Items added!");
					} // if
				} // if

				i++;
			} while (i < listValue);// do-while
			input.close();
		} // try

		catch (FileNotFoundException ex) {
			System.out.print("\nFailed to find the file: " + nameOfFile.getAbsolutePath());
			loadSuccessful = false;
		} // catch

		catch (InputMismatchException ex) {
			System.out.println("\nType of input was not expected for the line being read.");
			System.out.println(ex.getMessage());
			loadSuccessful = false;
		} // catch

		catch (NumberFormatException ex) {
			System.out.println("\nFailed to convert String text into an integer or double value.");
			System.out.println(ex.getMessage());
			loadSuccessful = false;
		} // catch

		catch (NoSuchElementException ex) {
			System.out.println("\nYou might be missing some data. Check for any missing data in your file.");
			loadSuccessful = false;
		} // catch

		catch (Exception ex) {
			// Like an "else" catch(Exception should come last as the catch all.
			System.out.println("\nSomething went wrong, check input file before trying again");
			ex.printStackTrace();
			loadSuccessful = false;
		} // catch
		if (loadSuccessful == false) {

		}

		return loadSuccessful;
	}// loadInputFile

	/**
	 * method that prints information about all the items
	 */
	public void printList() {
		int i = 0;

		if (mySize < 1) {
			System.out.println("There isnt anything in your list!");
		} // if

		else {
			for (i = 0; i < mySize; i++) {
				System.out.println("\nItem " + (i + 1) + ": " + myItems[i].toString());
			} // for
		} // else
	}// printList
}// ShoppingCartGjidoda
