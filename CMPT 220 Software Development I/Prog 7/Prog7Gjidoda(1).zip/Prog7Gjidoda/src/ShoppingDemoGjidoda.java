import java.io.File;
import java.text.NumberFormat;
import java.util.Locale;
import java.util.Scanner;

/**
 * 
 * @author Joey0027 <br>
 * 
 *         Prog 7 <br>
 *         Due Date and Time: 4/22/21 before 9:00 AM <br>
 * 
 *         Purpose: A program that can add items to a shopping list as well as
 *         tell you total price, total quantity of items, least and most
 *         expensive items, and all the info of each item. As well as remove the
 *         most expensive item. <br>
 * 
 *         Input: input file input, A, L, M, N, T, P, D, or Q if A, input name,
 *         quantity and price of item <br>
 * 
 *         Output: First greets user and explains the program <br>
 *         Then asks for the file location <br>
 *         If A: asks for name, quantity and price <br>
 *         If L: prints the least expensive name and price <br>
 *         If M: prints most expensive name and price <br>
 *         If N: prints the total number of items in car <br>
 *         If T: prints the total cost of all items <br>
 *         If P: prints all details of each item <br>
 *         If D: prints if most expensive was removed <br>
 *         If Q: says goodbye and thank you <br>
 * 
 *         Certification of Authenticity:<br>
 * 
 *         I certify that this lab is entirely my own work.<br>
 *
 */
public class ShoppingDemoGjidoda {
	/**
	 * universal scanner for ShoppingDemoGjidoda
	 */
	static Scanner keyboard = new Scanner(System.in);

	/**
	 * main method
	 * 
	 * @param args array of strings that is passed through main
	 */
	public static void main(String[] args) {

		// variables
		ShoppingCartGjidoda shoppingCart = new ShoppingCartGjidoda();
		char userInput;
		String itemName = null, fileName = null;
		int itemQuant = 0;
		double itemPrice = 0;
		NumberFormat format = NumberFormat.getCurrencyInstance(Locale.US);
		ItemGjidoda item = new ItemGjidoda(itemName, itemQuant, itemPrice);
		File inputFile;
		boolean loadUnsuccessul = true;

		// greet
		System.out.println("Hello, this is a program that tracks your grocery list!");
		do {

			// ask the user for the path and name to the file
			System.out.print("\nFirst enter the filename with your items: ");
			fileName = keyboard.next();

			// the catch for the file
			inputFile = new File(fileName);

			loadUnsuccessul = true;

			// if it returns false, there is a problem, so return, in order to end program
			if (shoppingCart.loadInputFile(inputFile) != true) {
				System.out.println("Please try again");
				shoppingCart = new ShoppingCartGjidoda();
				loadUnsuccessul = false;
			} // if

		} while (loadUnsuccessul != true);

		do {
			System.out.println("\nInput A to add an item.");
			System.out.println("Input L to find least expensive.");
			System.out.println("Input M to find most expensive.");
			System.out.println("Input N to find the number of items in the cart.");
			System.out.println("Input T to find the total cost of all items.");
			System.out.println("Input P to print out details.");
			System.out.println("Input D to delete the most expensice item.");
			System.out.println("Input Q to quit.");
			System.out.println("\nEnter menu choice: ");
			userInput = keyboard.next().charAt(0);
			userInput = Character.toUpperCase(userInput);

			// switch for menu choice
			switch (userInput) {

			case 'A':
				System.out.println("\nItem " + (shoppingCart.getSize() + 1));
				System.out.println("\nEnter item name: ");
				itemName = keyboard.next();

				// repeat until input is valid
				do {
					System.out.println("Enter item quantity: ");
					itemQuant = keyboard.nextInt();
					if (itemQuant <= 0) {
						System.out.println("Invalid Input!");
					} // if
				} while (itemQuant <= 0);// do-while

				// repeat until input is valid
				do {
					System.out.println("Enter item price: ");
					itemPrice = keyboard.nextDouble();
					if (itemPrice <= 0) {
						System.out.println("Invalid Input!");
					} // if
				} while (itemPrice <= 0);// do-while

				// assigns variables to item
				item = new ItemGjidoda(itemName, itemQuant, itemPrice);

				// add to cart, as well as prompt that it was added
				if (shoppingCart.addToCart(item) == true) {
					System.out.println("\nItem added!");
				} // if

				// if not added
				else {
					System.out.println("\nThere are already 10 items on your list!");
				} // else

				break;

			case 'L':

				// check for invalid input
				if (shoppingCart.getSize() < 1) {
					System.out.println("\nThere isnt anything on your list!");
				} // if
				else {
					System.out.println("\nThe least expensive item is " + shoppingCart.findLeastExpensive().toString());
				} // else

				break;// case L

			case 'M':

				// check for invalid input
				if (shoppingCart.getSize() < 1) {
					System.out.println("\nThere isnt anything on your list!");
				} // if
				else {
					System.out.println("\nThe most expensive item is " + shoppingCart.findMostExpensive().toString());
				} // else

				break;// case M

			case 'N':

				// print number of items
				System.out.println("\nTotal number of items: " + shoppingCart.findNumItems());

				break;// case N

			case 'T':

				// print total cost
				System.out.println("\nTotal cost of all items: " + format.format(shoppingCart.calcTotal()));

				break;// case T

			case 'P':

				// print all info of each item
				shoppingCart.printList();

				break;// case P

			case 'D':

				// check for invalid input
				if (shoppingCart.getSize() < 1) {
					System.out.println("\nNothing was removed because there isnt anything in your list.");
				} // if

				// removes most expensive and tells you
				else {
					shoppingCart.removeMostExpensive();
					System.out.println("\nMost Expensive item removed.");
					System.out.println("You are now back to adding item " + (shoppingCart.getSize() + 1));
				} // else

				break;// case D

			default:

				if (userInput != 'Q') {
					System.out.println("\nInvalid Input!");// default case (if wrong)
				}

			}// switch
		} while (userInput != 'Q');// do-while

		// goodbye
		System.out.println("\nThank you, goodbye.");
		keyboard.close();
	}// main

}// ShoppingDemoGjidoda
