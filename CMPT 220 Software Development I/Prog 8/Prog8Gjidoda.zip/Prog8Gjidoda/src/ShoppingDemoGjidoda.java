import java.io.File;
import java.io.FileNotFoundException;
import java.text.NumberFormat;
import java.util.InputMismatchException;
import java.util.Locale;
import java.util.NoSuchElementException;
import java.util.Scanner;

/**
 * 
 * @author Joey0027 <br>
 * 
 *         Prog 8 <br>
 *         Due Date and Time: 4/28/21 before 9:00 AM <br>
 * 
 *         Purpose: A program that can add items to a shopping list as well as
 *         tell you total price, total quantity of items, all the info of each
 *         item, remove specific item, and give info on specific items. <br>
 * 
 *         Input: input file input, 1, 2, 3, 4, 5, 6, 7, 8, 9 or 0 if 1, input
 *         name, quantity and price of item <br>
 * 
 *         Output: First greets user and explains the program <br>
 *         Then asks for the file location <br>
 *         If 1: asks for name, quantity and price <br>
 *         If 2: asks for item name, then say if deleted <br>
 *         If 3: prints all items <br>
 *         If 4: asks for item name and if found prints info <br>
 *         If 5: prints the total number of items <br>
 *         If 6: prints total cost <br>
 *         If 7: prints if list is empty <br>
 *         If 8: prints if list is full <br>
 *         if 9: prints if list is cleared <br>
 *         If 0: says goodbye and thank you <br>
 * 
 *         Certification of Authenticity:<br>
 * 
 *         I certify that this lab is entirely my own work.<br>
 *
 */
public class ShoppingDemoGjidoda
{
	/**
	 * universal scanner for ShoppingDemoGjidoda
	 */
	static Scanner keyboard = new Scanner(System.in);

	/**
	 * main method
	 * 
	 * @param args array of strings that is passed through main
	 */
	public static void main(String[] args)
	{
		// variables
		KeyedListGjidoda keyedList = new KeyedListGjidoda();
		String itemName = null, findItem = null;
		int itemQuant = 0;
		char userInput = 0;
		double itemPrice = 0;
		NumberFormat format = NumberFormat.getCurrencyInstance(Locale.US);
		ItemGjidoda item = new ItemGjidoda(itemName, itemQuant, itemPrice);

		// greet
		System.out.println("Hello, this is a program that tracks your grocery list!");

		// Load file
		if (loadInputFile(keyedList) == false)
		{
			return;
		}

		do
		{
			System.out.println("\nInput 1 to add an item.");
			System.out.println("Input 2 to delete an item from the list.");
			System.out.println("Input 3 to print each item in the list.");
			System.out.println("Input 4 to search for an item in the list.");
			System.out.println("Input 5 for the total number of items in the list.");
			System.out.println("Input 6 for total the cost of the items in the list.");
			System.out.println("Input 7 to determine whether the list is empty.");
			System.out.println("Input 8 to determine whether the list is full.");
			System.out.println("Input 9 to clear.");
			System.out.println("Input 0 to quit.");
			System.out.println("\nEnter menu choice: ");
			userInput = keyboard.next().charAt(0);

			// switch for menu choice
			switch (userInput)
			{

			case '1':
				System.out.println("\nItem " + (keyedList.getSize() + 1));
				System.out.println("\nEnter item name: ");
				itemName = keyboard.next();

				// repeat until input is valid
				do
				{
					System.out.println("Enter item quantity: ");
					itemQuant = keyboard.nextInt();
					if (itemQuant <= 0)
					{
						System.out.println("Invalid Input!");
					} // if
				} while (itemQuant <= 0);// do-while

				// repeat until input is valid
				do
				{
					System.out.println("Enter item price: ");
					itemPrice = keyboard.nextDouble();
					if (itemPrice <= 0)
					{
						System.out.println("Invalid Input!");
					} // if
				} while (itemPrice <= 0);// do-while

				// assigns variables to item
				item = new ItemGjidoda(itemName, itemQuant, itemPrice);

				// add to cart, as well as prompt that it was added
				if (keyedList.add(item) == true)
				{
					System.out.println("\nItem added!");
				} // if

				// if not added
				else
				{
					System.out.println("\nThere are already 20 items on your list, or you added a duplicate!");
				} // else

				break;// case 1

			case '2':

				System.out.println("\nEnter the name of the item you wish to remove: ");
				itemName = keyboard.next();
				boolean removedItem = keyedList.remove(itemName);
				if (removedItem == true)
				{
					System.out.println("\n" + itemName + " removed.");
					System.out.println("You are now back to adding item " + (keyedList.getSize() + 1));
				} // if

				else
				{
					System.out.println("\n" + itemName + " was not found.");
				} // else

				break;// case 2

			case '3':

				// print all info of each item
				keyedList.print();

				break;// case 3

			case '4':
				System.out.println("\nEnter the name of the item you wish to find: ");
				findItem = keyboard.next();
				ItemGjidoda retrievedItem = keyedList.retrieve(findItem);

				if (retrievedItem != null)
				{
					System.out.println("\nYou do have: " + retrievedItem.toString());
				} // if

				else
				{
					System.out.println("\n" + findItem + " is not in your list.");
				} // else

				break;// case 4

			case '5':

				// print number of items
				System.out.println("\nTotal number of items: " + keyedList.getCount());

				break;// case 5

			case '6':

				// print total cost
				System.out.println("\nTotal cost of all items: " + format.format(keyedList.calcTotal()));

				break;// case 6

			case '7':

				// if false it is not empty
				if (keyedList.isEmpty() == false)
				{
					System.out.println("\nYour list is not empty.");
				} // if

				// is empty
				else
				{
					System.out.println("\nYour list is empty.");
				} // else

				break;// case 7

			case '8':

				// if false it is not full
				if (keyedList.isFull() == false)
				{
					System.out.println("\nYour list is not full.");
				} // if

				// is full
				else
				{
					System.out.println("\nYour list is full.");
				} // else

				break;// case 8

			case '9':

				// clears list
				keyedList.clear();
				System.out.println("\nYour list has been cleared.");

				break;// case 9

			default:

				// if any other input, then it is invalid
				if (userInput != '0')
				{
					System.out.println("\nInvalid Input!");// default case (if wrong)
				} // if

			}// switch
		} while (userInput != '0');// do-while

		// goodbye
		System.out.println("\nThank you, goodbye.");
		keyboard.close();
	}// main

	/**
	 * * method that loads input file and adds all items
	 * 
	 * @param keyedList the universal list
	 * @return t or f if processed
	 */
	public static boolean loadInputFile(KeyedListGjidoda keyedList)
	{
		boolean sucsessful = true;
		File inputFile;
		String fileName = null, inputName = null;
		int i = 0, inputQuant = 0, listValue = 0;
		double inputPrice = 0.0;
		ItemGjidoda item = null;

		// ask the user for the path and name to the file
		System.out.print("First enter the filename with your items: ");
		fileName = keyboard.next();

		// the catch for the file
		inputFile = new File(fileName);

		// try to open and use the file, if possible
		try
		{

			Scanner input = new Scanner(inputFile);
			listValue = input.nextInt();

			// An exception is thrown if you try to read past the end-of-file.
			do
			{
				inputName = input.next();
				inputQuant = input.nextInt();
				inputPrice = input.nextDouble();
				item = new ItemGjidoda(inputName, inputQuant, inputPrice);

				// add to cart, as well as prompt that it was added
				if (keyedList.add(item) == true)
				{
					if (i == 0)
					{
						System.out.println("\n" + (i + 1) + " Item added!");
					} // if
					if (i > 0)
					{
						System.out.println("\n" + (i + 1) + " Items added!");
					} // if
				} // if

				i++;
			} while (i < listValue);// do-while
			input.close();
		} // try

		catch (FileNotFoundException ex)
		{
			System.out.print("\nFailed to find the file: " + inputFile.getAbsolutePath());
			sucsessful = false;
		} // catch

		catch (InputMismatchException ex)
		{
			System.out.println("\nType of input was not expected for the line being read.");
			System.out.println(ex.getMessage());
			sucsessful = false;
		} // catch

		catch (NumberFormatException ex)
		{
			System.out.println("\nFailed to convert String text into an integer or double value.");
			System.out.println(ex.getMessage());
			sucsessful = false;
		} // catch

		catch (NoSuchElementException ex)
		{
			System.out.println("\nYou might be missing some data. Check for any missing data in your file.");
			sucsessful = false;
		} // catch

		catch (Exception ex)
		{
			// Like an "else" catch(Exception should come last as the catch all.
			System.out.println("\nSomething went wrong, check input file before trying again");
			ex.printStackTrace();
			sucsessful = false;
		} // catch
		return sucsessful;
	}// loadInputFile

}// ShoppingDemoGjidoda
