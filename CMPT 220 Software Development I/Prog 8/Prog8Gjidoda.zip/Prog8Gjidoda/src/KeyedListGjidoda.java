/**
 * 
 * @author Joey0027
 *
 *         This is class definition for KeyedListGjidoda
 */
public class KeyedListGjidoda
{
	/**
	 * instance variable for item array
	 */
	private ItemGjidoda[] myItems;

	/**
	 * instance variable for size of array
	 */
	private int mySize;

	/**
	 * constructor
	 */
	public KeyedListGjidoda()
	{
		int i = 0;
		myItems = new ItemGjidoda[20];

		for (i = 0; i >= myItems.length; i++)
		{
			myItems[i] = null;
		} // for
		mySize = 0;
	}// constructor

	/**
	 * method that gets size
	 * 
	 * @return size of list
	 */
	public int getSize()
	{
		return mySize;
	}// getSize

	/**
	 * method that clears list
	 */
	public void clear()
	{
		mySize = 0;
		myItems = new ItemGjidoda[20];
	}// clear

	/**
	 * method that finds items index
	 * 
	 * @param keyValue incoming item name
	 * @return index number
	 */
	private int findIndex(String keyValue)
	{
		int index = -1, i = 0;

		for (i = 0; i < mySize; i++)
		{
			if (keyValue.compareToIgnoreCase(myItems[i].getName()) == 0)
			{
				index = i;
			} // if
		} // for

		return index;
	}// findIndex

	/**
	 * method that adds item in ascending order
	 * 
	 * @param product incoming item
	 * @return t or f if added
	 */
	public boolean add(ItemGjidoda product)
	{
		boolean ans = false;

		if (mySize < myItems.length)
		{
			myItems[mySize] = product;
			mySize++;
			ans = true;
		} // if
		else
		{
			ans = false;
		} // else

		for (int i = 0; i < mySize - 1; i++)
		{
			// if it is duplicate
			if (product.getName().compareToIgnoreCase(myItems[i].getName()) == 0)
			{
				remove(product.getName());
				ans = false;
			} // if
		} // for

		for (int i = 0; i < mySize - 1; i++)
		{
			// for each item, compare it against each other item
			for (int j = 0; j < mySize - i - 1; j++)
			{
				// swap numbers if j is greater than j+ 1
				if (myItems[j].getName().compareToIgnoreCase(myItems[j + 1].getName()) > 0)
				{
					ItemGjidoda temp = myItems[j];
					myItems[j] = myItems[j + 1];
					myItems[j + 1] = temp;
				} // if
			} // for

		} // for

		for (int i = 0; i < mySize; i++)
		{

		}
		return ans;
	}// addToCart

	/**
	 * method that removes specific item
	 * 
	 * @param keyValue incoming item name
	 * @return t or f if removed
	 */
	public boolean remove(String keyValue)
	{
		boolean removed = false;
		int i = 0, j = 0;
		ItemGjidoda[] myList = new ItemGjidoda[20];
		int name = findIndex(keyValue);

		if (name != -1)
		{
			for (i = 0, j = 0; i < mySize; i++)
			{
				if (name != i)
				{
					myList[j++] = myItems[i];
					removed = true;
				} // if
			} // for
			mySize--;
			myItems = myList;
		} // if

		return removed;
	}// remove

	/**
	 * method that retrieves item
	 * 
	 * @param keyValue incoming item name
	 * @return item info
	 */
	public ItemGjidoda retrieve(String keyValue)
	{
		ItemGjidoda retreivedItem = null;
		int i = 0;

		for (i = 0; i < mySize; i++)
		{
			if (keyValue.compareToIgnoreCase(myItems[i].getName()) == 0)
			{
				retreivedItem = myItems[i];
			} // if
		} // for

		return retreivedItem;
	}// is

	/**
	 * method that checks if list is empty
	 * 
	 * @return t or f, if empty or not
	 */
	public boolean isEmpty()
	{
		boolean empty = false;

		if (mySize < 1)
		{
			empty = true;
		} // if

		return empty;
	}// isEmpty

	/**
	 * method that checks if list is full
	 * 
	 * @return t or f, if full or not
	 */
	public boolean isFull()
	{
		boolean full = false;

		if (mySize == myItems.length)
		{
			full = true;
		} // if

		return full;
	}// isFull

	/**
	 * method that prints information about all items
	 */
	public void print()
	{
		int i = 0;

		if (isEmpty() == true)
		{
			System.out.println("\nThere isnt anything in your list!");
		} // if

		else
		{
			for (i = 0; i < mySize; i++)
			{
				System.out.println("\nItem " + (i + 1) + ": " + myItems[i].toString());
			} // for
		} // else

	}// print

	/**
	 * method that gets total items
	 * 
	 * @return total items
	 */
	public int getCount()
	{
		int count = 0;

		int i = 0;

		for (i = 0; i < mySize; i++)
		{
			count += myItems[i].getQuant();
		} // for

		return count;
	}// getCount

	/**
	 * method that calculates total
	 * 
	 * @return total cost
	 */
	public double calcTotal()
	{
		double total = 0.0;
		int i = 0;

		for (i = 0; i < mySize; i++)
		{
			total += myItems[i].getQuant() * myItems[i].getPrice();
		} // for

		return total;
	}// calTotal

}// KeyedListGjidoda
