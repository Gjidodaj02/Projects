
/**
 * Imports for the class ItemGjidoda
 */
import java.text.NumberFormat;
import java.util.Locale;

/**
 * 
 * @author Joey0027 <br>
 * 
 *         This is class definition for ItemGjidoda
 */
public class ItemGjidoda
{

	/**
	 * Instance variable for item name
	 */
	private String myName;

	/**
	 * Instance variable for item quantity
	 */
	private int myQuant;
	/**
	 * Instance variable for item price
	 */
	private double myPrice;

	/**
	 * null constructor
	 */
	public ItemGjidoda()
	{
		myName = "NONE";
		myQuant = -1111;
		myPrice = 999.99;
	}// ItemGjidoda

	/**
	 * Default constructor
	 * 
	 * @param newName  incoming name
	 * @param newQuant incoming quantity
	 * @param newPrice incoming price
	 */
	public ItemGjidoda(String newName, int newQuant, double newPrice)
	{
		myName = newName;
		myQuant = newQuant;
		myPrice = newPrice;
	}// full constructor

	/**
	 * method that sets item name
	 * 
	 * @param newName new incoming name
	 */
	public void setName(String newName)
	{
		myName = newName;
	}// setName

	/**
	 * method that sets item quantity
	 * 
	 * @param newQuant new incoming quantity
	 */
	public void setQuant(int newQuant)
	{
		myQuant = newQuant;
	}// setQuant

	/**
	 * method that sets item price
	 * 
	 * @param newPrice new incoming price
	 */
	public void setPrice(double newPrice)
	{
		myPrice = newPrice;
	}// setPrice

	/**
	 * method that returns item name
	 * 
	 * @return name if item
	 */
	public String getName()
	{
		return myName;
	}// getName

	/**
	 * method that returns item quantity
	 * 
	 * @return quantity of item
	 */
	public int getQuant()
	{
		return myQuant;
	}// getQuantity

	/**
	 * method that returns item price
	 * 
	 * @return price of item
	 */
	public double getPrice()
	{
		return myPrice;
	}// getPrice

	/**
	 * method that converts data to string
	 */
	public String toString()
	{
		String result;
		NumberFormat format = NumberFormat.getCurrencyInstance(Locale.US);

		result = myName;
		result += "\nPrice: " + format.format(myPrice);
		result += "\nQuantity: " + myQuant + "\n";

		return result;
	}// toString
}// ItemGjidoda