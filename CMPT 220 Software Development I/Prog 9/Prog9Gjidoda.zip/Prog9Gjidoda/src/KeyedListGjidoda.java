/**
 * 
 * @author Joey0027
 *
 *         This is class definition for KeyedListGjidoda
 */
public class KeyedListGjidoda
{
	/**
	 * instance variable for size of array
	 */
	private int mySize;

	/**
	 * instance variable for Node myHead
	 */
	private NodeGjidoda myHead;

	/**
	 * constructor
	 */
	public KeyedListGjidoda()
	{
		myHead = null;
		mySize = 0;
	}// constructor

	/**
	 * method that gets size
	 * 
	 * @return size of list
	 */
	public int getSize()
	{
		return mySize;
	}// getSize

	/**
	 * method that returns head
	 * 
	 * @return head
	 */
	public NodeGjidoda getHead()
	{
		return myHead;
	}

	/**
	 * method that sets head
	 * 
	 * @param newHead incoming head
	 */
	public void setHead(NodeGjidoda newHead)
	{
		myHead = newHead;
	}

	/**
	 * method that clears list
	 */
	public void clear()
	{
		myHead = null;
	}// clear

	/**
	 * method that adds item in ascending order
	 * 
	 * @param product incoming item
	 * @return t or f if added
	 */
	public boolean add(ItemGjidoda product)
	{
		boolean ans = false;
		NodeGjidoda curr = myHead, prev = null;
		NodeGjidoda newGuy = new NodeGjidoda(product);

		boolean isSeen = false;
		while ((curr != null) && (!ans))
		{
			if ((product.getName().compareToIgnoreCase(curr.getData().getName()) == 0))
			{
				isSeen = true;
				ans = true;
			} // if

			else if ((product.getName().compareToIgnoreCase(curr.getData().getName()) < 0))
			{
				ans = true;
			} // if

			else
			{
				prev = curr;
				curr = curr.getNext();
			} // else
		} // while

		if (prev == null && !isSeen)
		{
			newGuy.setNext(curr);
			myHead = newGuy;
			mySize++;
		} // if

		else if (!isSeen)
		{
			newGuy.setNext(curr);
			prev.setNext(newGuy);
			mySize++;
		} // else if

		return ans && !isSeen;
	}// addToCart

	/**
	 * method that removes specific item
	 * 
	 * @param keyValue incoming item name
	 * @return t or f if removed
	 */
	public boolean remove(String keyValue)
	{
		boolean remove = false;
		NodeGjidoda curr = myHead;
		NodeGjidoda prev = null;

		while ((curr != null) && (!remove))
		{
			if (keyValue.compareToIgnoreCase(curr.getData().getName()) == 0)
			{
				remove = true;
				mySize--;
			} // if

			else
			{
				prev = curr;
				curr = curr.getNext();
			} // else
		} // while

		if (remove)
		{
			if (prev == null)
			{
				myHead = curr.getNext();
			} // if

			else
			{
				prev.setNext(curr.getNext());
			} // else
		} // if
		return remove;
	}// remove

	/**
	 * method that retrieves item
	 * 
	 * @param keyValue incoming item name
	 * @return item info
	 */
	public ItemGjidoda retrieve(String keyValue)
	{
		ItemGjidoda retreivedItem = null;
		NodeGjidoda curr = myHead;

		while (curr != null)
		{
			if (keyValue.compareToIgnoreCase(curr.getData().getName()) == 0)
			{
				retreivedItem = curr.getData();
			} // if

			curr = curr.getNext();
		} // for

		return retreivedItem;
	}// is

	/**
	 * method that checks if list is empty
	 * 
	 * @return t or f, if empty or not
	 */
	public boolean isEmpty()
	{
		return (myHead == null);
	}// isEmpty

	/**
	 * method that checks if list is full
	 * 
	 * @return false because list can't be full
	 */
	public boolean isFull()
	{
		return false;
	}// isFull

	/**
	 * method that prints information about all items
	 */
	public void print()
	{

		NodeGjidoda curr = myHead;

		if (isEmpty() == true)
		{
			System.out.println("\nThere isnt anything in your list!");
		} // if

		else
		{
			while (curr != null)
			{
				System.out.println(curr.getData());
				curr = curr.getNext();
			} // while

		} // else

	}// print

	/**
	 * method that gets total items
	 * 
	 * @return total items
	 */
	public int getCount()
	{
		int count = 0;
		NodeGjidoda curr = myHead;

		while (curr != null)
		{
			count += curr.getData().getQuant();
			curr = curr.getNext();
		} // for

		return count;
	}// getCount

	/**
	 * method that calculates total
	 * 
	 * @return total cost
	 */
	public double calcTotal()
	{
		double total = 0.0;
		NodeGjidoda curr = myHead;

		while (curr != null)
		{
			total += curr.getData().getQuant() * curr.getData().getPrice();
			curr = curr.getNext();
		} // for

		return total;
	}// calTotal

}// KeyedListGjidoda
