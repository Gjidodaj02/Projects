/**
 * 
 * @author Joey0027
 *
 *         This is class definition for NodeGjidoda
 */
public class NodeGjidoda
{
	/**
	 * Instance variable for item data
	 */
	private ItemGjidoda myData;

	/**
	 * Instance variable for next data
	 */
	private NodeGjidoda myNext;

	/**
	 * constructor
	 */
	public NodeGjidoda()
	{
		myData = null;
		myNext = null;
	}// NodeGjidoda

	/**
	 * method that sets new values to variables
	 * 
	 * @param newData new incoming data
	 */
	public NodeGjidoda(ItemGjidoda newData)
	{
		myData = newData;
		myNext = null;
	}// NodeGjidoda

	/**
	 * method that gets data
	 * 
	 * @return data
	 */
	public ItemGjidoda getData()
	{
		return myData;
	}// getData

	/**
	 * method that gets next
	 * 
	 * @return next data
	 */
	public NodeGjidoda getNext()
	{
		return myNext;
	}// getNext

	/**
	 * method that sets data
	 * 
	 * @param newData new incoming data
	 */
	public void setData(ItemGjidoda newData)
	{
		myData = newData;
	}// setData

	/**
	 * method that sets next
	 * 
	 * @param newNext new incoming data for next
	 */
	public void setNext(NodeGjidoda newNext)
	{
		myNext = newNext;
	}// setNext

}// NodeGjidoda
