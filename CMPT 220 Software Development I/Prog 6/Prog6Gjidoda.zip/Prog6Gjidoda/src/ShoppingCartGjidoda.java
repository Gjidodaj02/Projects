/**
 * 
 * @author Joey0027
 *
 * This is a class definition for StepsGjidoda
 */
public class ShoppingCartGjidoda {

	/**
	 * Instance variable for setting array for items
	 */
	private ItemGjidoda[] myItems = new ItemGjidoda[10];
	
	/**
	 * Instance variable for size of array
	 */
	private int mySize;
	
	/**
	 * null constructor
	 */
	public ShoppingCartGjidoda()
	{
		myItems = new ItemGjidoda[10];
		mySize = 0;
	}//ShoppingCartGjidoda
	
	/**
	 * method that returns the array size
	 * @return size of the array
	 */
	public int getSize()
	{
		return mySize;
	}//getSize
	
	/**
	 * method that adds item to cart
	 * @param item new incoming item
	 * @return boolean t or f, for if item was added
	 */
	public boolean addToCart(ItemGjidoda item)
	{
		boolean ans = false;
		
		if (mySize < 10)
			{
				myItems[mySize] = item;
				mySize ++;
				ans = true;
			}//if
		else ans = false;
		
		return ans;
	}//addToCart
	
	/**
	 * method that finds most expensive and returns it
	 * @return most expensive number
	 */
	public int findMostExpensive()
	{
		double mostExpensive = myItems[0].getPrice();
		int i = 0;
		int mostInt = 0;
		
		for (i = 0; i < mySize; i++)
			{
				if (myItems[i].getPrice() >= mostExpensive && myItems[i].getName() != "NONE")
					{
						mostExpensive = myItems[i].getPrice();
						mostInt = i;
					}//if
			}//for
		
		return mostInt;
	}//findMostExpensive
	
	/**
	 * method that finds least expensive and returns it
	 * @return least expensive number
	 */
	public int findLeastExpensive()
	{
		double leastExpensive = myItems[findMostExpensive()].getPrice();
		int i = 0;
		int leastInt = 0;

		for (i = 0; i < mySize; i++)
			{
				if (myItems[i].getPrice() <= leastExpensive && myItems[i].getName() != "NONE")
					{
						leastExpensive = myItems[i].getPrice();
						leastInt = i;
					}//if
			}//for
		
		return leastInt;
		
	}//findLeastExpensive
	
	/**
	 * method that calculates the total cost
	 * @return total cost
	 */
	public double calcTotal()
	{
		double total = 0.0;
		int i = 0;
		
		for (i = 0; i < mySize; i++)
			{
				total += myItems[i].getQuant() * myItems[i].getPrice();
			}//for
		
		return total;
	}//caltTotal
	
	/**
	 * method that finds the total number of items
	 * @return number of items
	 */
	public int findNumItems()
	{
		int numItems = 0;
		int i = 0;
		
		for (i = 0; i < mySize; i++)
			{
				numItems += myItems[i].getQuant();
			}//for
		
		return numItems;
	}//findNumTimes
	
	/**
	 * method that removes most expensive item
	 */
	public void removeMostExpensive()
	{
		int maxNum = findMostExpensive();
		int i = 0, j = 0;
		ItemGjidoda[] copy = new ItemGjidoda[10];

		for (i = 0, j = 0; i < mySize; i++) {
		    if (i != maxNum) {
		        copy[j++] = myItems[i];
		    }
		}
		
		myItems = copy;
		mySize--;
	}//removeMostExpensive
	
	/**
	 * method that prints information about all the items
	 */
	public void printList()
	{
		int i = 0;
		
		if (mySize < 1)
			{
				System.out.println("There isnt anything in your list!");
			}//if
		else
		{
			for (i = 0; i < mySize; i++)
				{
					if (myItems[i].getName() != "NONE")
						{
							System.out.println(myItems[i].toString());
						}//if
				}//for
		}//else
	}//printList
}//ShoppingCartGjidoda
