CREATE OR REPLACE VIEW VENDORJOINQUERY3 AS 
--Get all deliveries. (List vendor, park and snack numbers, their names, and the prices of the snacks) 
--Records: 24
SELECT V.VNUM, P.PNUM, S.SNUM, V.VENDORNAME, P.PARKNAME, S.SNACKNAME, S.PRICE 
FROM VENDORS V JOIN DELIVERS D ON V.VNUM = D.VNUM 
JOIN PARKS P ON P.PNUM = D.PNUM 
JOIN SNACKS S ON S.SNUM = D.SNUM; 

 
