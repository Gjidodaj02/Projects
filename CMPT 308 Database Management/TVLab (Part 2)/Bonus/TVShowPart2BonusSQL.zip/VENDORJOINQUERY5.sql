CREATE OR REPLACE VIEW VENDORJOINQUERY5 AS 
--Get all park numbers along with vendor number and name, that share locations, if any. 
--Records: 10
SELECT V.VNUM, HQLOC, PNUM, LOCATION AS PARKLOC 
FROM VENDORS V RIGHT JOIN PARKS P ON V.HQLOC = P.LOCATION; 

 
