CREATE OR REPLACE VIEW VENDORJOINQUERY4 AS 
--Get all park numbers and locations, along with snack numbers and locations that share locations, if any. 
--Records: 12
SELECT P.PNUM, P.LOCATION, S.SNUM, S.SOURCECITY 
FROM PARKS P LEFT JOIN SNACKS S ON P.LOCATION = S.SOURCECITY; 

 
