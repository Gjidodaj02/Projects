CREATE OR REPLACE VIEW VENDORJOINQUERY2 AS 
--Get all vendor and parks they deliver to. (List their numbers, names, and the amount they deliver)
--Records: 24
SELECT VNUM, PNUM, VENDORNAME, PARKNAME, AMOUNT 
FROM VENDORS JOIN DELIVERS USING (VNUM) 
JOIN PARKS USING (PNUM); 
