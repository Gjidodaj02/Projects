CREATE OR REPLACE VIEW VENDORJOINQUERY6 AS 
--Get all vendors and snacks number and name that share a location if any. 
--Records: 12
SELECT VNUM, VENDORNAME, SNUM, SNACKNAME 
FROM VENDORS V FULL JOIN SNACKS S ON V.HQLOC = S.SOURCECITY; 

 
