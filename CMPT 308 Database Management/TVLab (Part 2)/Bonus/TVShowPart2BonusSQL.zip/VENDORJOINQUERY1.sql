CREATE OR REPLACE VIEW VENDORJOINQUERY1 AS 
--Get all vendor and snack deliveries. (List snack number, name, sourcecity, and vendor number) 
--Records: 24
SELECT SNUM, SNACKNAME, SOURCECITY, VNUM 
FROM SNACKS NATURAL JOIN DELIVERS; 
